<section class="bg-[#d1e8ff] px-4 py-28 xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="nl__content grid gap-20 md:grid-cols-12">
            <div class="nl__content_inner col-span-6">
                <h2 class="text-primary text-5xl font-Oswald font-bold">
                    <? the_field('nl_heading'); ?>
                </h2>
                <p class="text-lg font-GTamerica font-normal text-charcoal my-7">
                    <? the_field('nl_description'); ?>
                </p>
            </div>
            <div class="nl__btn col-span-6">
                <?php echo do_shortcode('[contact-form-7 id="75f0c54" title="News letter"]'); ?>
            </div>
        </div>
    </div>
</section>