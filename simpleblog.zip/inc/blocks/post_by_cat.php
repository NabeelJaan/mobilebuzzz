<section class="px-4 pt-[74px] xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        
        <div class="mrp_head border-b flex items-center justify-between pb-4 mb-7">
            <div>
                <h2 class="text-primary text-3xl font-Oswald font-bold">
                    <?php the_field('post_cat_heading'); ?>
                </h2>
            </div>
            <div class="flex items-center">
                <div>
                    <a href="#" class="text-base text-secondary font-medium">View All Posts</a>
                </div>
                <div>
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                            <path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"/>
                        </svg>
                    </span>
                </div>
            </div>
        </div>

        <div class="pbc__wrapper grid gap-10 grid-flow-row md:grid-cols-2 lg:grid-cols-3">

            <?php 
                $pbc_cat_name = get_field('pbc_name');

                // var_dump($pbc_cat_name);

                $args = array(
                    'post_type'         =>  'post',
                    'posts_per_page'    =>  3,
                    'category_name'     =>  $pbc_cat_name,
                    'post_status'       =>  'publish'
                );
                $the_query = new WP_Query( $args );
                
                if ( $the_query->have_posts() ):
                    while ( $the_query->have_posts() ) : $the_query->the_post();

            ?>

            <div class="single_cards">
                <div class="post_img mb-[14px]">
                    <a href="<?php the_permalink(); ?>" class="block overflow-hidden font-Oswald">
                        <?php the_post_thumbnail( 'pb_cat', [ 'class' => 'transition ease-in-out duration-300 hover:scale-105' ] );?>
                    </a>
                </div>
                <div class="content">
                    <ul class="bus_types flex items-center gap-2 mt-6">
                        <?php foreach((get_the_category()) as $category) : ?>
                            <li>
                                <a  href="<?php echo esc_url(get_category_link($category->term_id)); ?>" 
                                    class="text-sm text-secondary font-monospace font-medium leading-5">
                                    <?php echo esc_html($category->name); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <h3 class="text-primary text-xl font-Oswald font-semibold my-2">
                        <?php the_title(); ?>
                    </h3>

                    <p class="text-base font-Gtamerica font-normal mb-6">
                        <?php echo wp_trim_words(get_the_excerpt(), 18, '...'); ?>
                    </p>
                    
                    <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" class="c_inner flex items-center">
                        <div class="w-[48px]">
                            <img class="w-[48px] h-[48px] rounded-full" src="<?php echo get_avatar_url(get_the_author_meta('ID')); ?>" alt="<?php the_author(); ?>">
                        </div>
                        <div class="ml-3 max-w-[155px]">
                            <h4 class="text-sm font-Oswald"><?php the_author(); ?></h4>
                            <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished" class="text-sm text-charcoal font-monospace font-normal">
                                <?php echo get_the_date(); ?>
                            </time>
                        </div>
                    </a>
                </div>
            </div>

            <?php
                endwhile;

                wp_reset_postdata();

                endif;
            ?>

        </div>
    </div>
</section>