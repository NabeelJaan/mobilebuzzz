
<section class="px-4 xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="book__content relative bg-[#f9f2ff] px-11 pb-20 pt-[100px] flex rounded-md my-[74px] transition-all ease-in-out duration-500 hover:shadow-lg">
            <div class="content__inner relative">
                <h2 class="text-primary text-5xl font-Oswald font-bold">
                    <? the_field('book_heading'); ?>
                </h2>
                <p class="text-lg font-Oswald font-normal my-7">
                    <? the_field('book_description'); ?>
                </p>

                <?php 
                    $bk__btn = get_field('book_button');
                    if( $bk__btn ) :
                ?>
                    <div class="bk__btn">
                        <a  class="text-white rounded-md px-[35px] text-lg leading-[57px] font-Oswald font-semibold bg-secondary inline-flex"
                            href="<?php echo esc_url( $bk__btn['url'] ); ?>" 
                            target="<?php echo esc_attr( $bk__btn['target'] ); ?>">
                            <?php echo esc_html( $bk__btn['title'] ); ?>
                        </a>
                    </div>

                <?php endif; ?>
            </div>
            <?php 
                $bk__img = get_field('book_image');
                if( $bk__img ) :
            ?>
            <div class="bk__img z-30">
                <img
                    class="absolute bottom-0 right-0"
                    src="<?php echo esc_url( $bk__img['url'] ) ?>" 
                    alt="<?php echo $bk__img['alt'] ?>"
                >
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>