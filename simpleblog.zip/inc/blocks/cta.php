<section class="bg-[#d1e8ff] px-4 py-28 xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="cta__content text-center">
            <h2 class="text-primary text-5xl font-Oswald font-bold">
                <? the_field('cta_heading'); ?>
            </h2>
            <p class="text-lg font-GTamerica font-normal text-charcoal my-7">
                <? the_field('cta_heading'); ?>
            </p>

            <?php 
                $cta__btn = get_field('cta_button');
                if( $cta__btn ) :
            ?>
            <div class="cta__btn">
                <a  class="text-white rounded-md px-[35px] text-lg leading-[57px] font-Oswald font-semibold bg-secondary inline-flex"
                    href="<?php echo esc_url( $cta__btn['url'] ); ?>" 
                    target="<?php echo esc_attr( $cta__btn['target'] ); ?>">
                    <?php echo esc_html( $cta__btn['title'] ); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>