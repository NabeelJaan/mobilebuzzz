<section class="px-4 bg-aliceblue xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="md:flex items-center justify-between">
            <div class="links__wrap">
                <ul class="md:flex md:items-center md:gap-5">
                    <li><a href="#" class="text-sm leading-[22px] font-normal font-GTamerica pr-[22px] py-[18px] inline-block">Latest Articles</a></li>
                    <li><a href="#" class="text-sm leading-[22px] font-normal font-GTamerica px-[22px] py-[18px] inline-block">Customer Service</a></li>
                    <li><a href="#" class="text-sm leading-[22px] font-normal font-GTamerica px-[22px] py-[18px] inline-block">Growth</a></li>
                    <li><a href="#" class="text-sm leading-[22px] font-normal font-GTamerica px-[22px] py-[18px] inline-block">Inside help</a></li>
                    <li><a href="#" class="text-sm leading-[22px] font-normal font-GTamerica px-[22px] py-[18px] inline-block">Support kit</a></li>
                </ul>
            </div>
            <div class="search__wrap">
                <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" class="injected-svg" data-src="/icons/search.svg" xmlns:xlink="http://www.w3.org/1999/xlink" role="img">
                        <path d="M19.25 19.25L15.5 15.5M4.75 11C4.75 7.54822 7.54822 4.75 11 4.75C14.4518 4.75 17.25 7.54822 17.25 11C17.25 14.4518 14.4518 17.25 11 17.25C7.54822 17.25 4.75 14.4518 4.75 11Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</section>

<section class="px-4 pt-10 xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="main_head mb-11 max-w-[630px]">
            <h1 class="text-[46px] font-Oswald font-bold mb-6">
                <?php the_field('ms_heading'); ?>
            </h1>
            <p  class="text-lg font-normal font-GTamerica text-charcoal">
                <?php the_field('ms_description'); ?>
            </p>
        </div>
        <nav class="">
            <ul class="grid grid-cols-2 gap-4 md:grid-flow-row md:grid-cols-4 md:gap-5">
                <li class=""><a href="#" class="text-charcoal font-GTamerica text-lg font-medium bg-aliceblue h-[56px] flex items-center justify-center rounded-[4px] transition-all ease-in-out duration-500 hover:shadow-md">Latest Articles</a></li>
                <li class=""><a href="#" class="text-charcoal font-GTamerica text-lg font-medium bg-aliceblue h-[56px] flex items-center justify-center rounded-[4px] transition-all ease-in-out duration-500 hover:shadow-md">Customer Service</a></li>
                <li class=""><a href="#" class="text-charcoal font-GTamerica text-lg font-medium bg-aliceblue h-[56px] flex items-center justify-center rounded-[4px] transition-all ease-in-out duration-500 hover:shadow-md">Growth</a></li>
                <li class=""><a href="#" class="text-charcoal font-GTamerica text-lg font-medium bg-aliceblue h-[56px] flex items-center justify-center rounded-[4px] transition-all ease-in-out duration-500 hover:shadow-md">Inside help</a></li>
            </ul>
        </nav>
    </div>
</section>