
<section class="px-4 py-[74px] xl:px-0">
    <div class="max-w-[1280px] mx-auto">
        <div class="mrp_head border-b flex items-center justify-between pb-4 mb-7">
            <div>
                <h2 class="text-primary font-Oswald text-3xl font-bold">Most Recent Post</h2>
            </div>
            <div>
                <a href="#" class="text-base text-secondary font-Oswald font-medium">View All Posts</a>
                <span></span>
            </div>
        </div>
        <div class="post_cards_wrapper grid gap-10 md:grid-cols-12">

        <?php

            $args = array(
                'post_type'         => 'post',
                'post_status'       => 'publish',
                'posts_per_page'    => 3
            );
            $cs1 = new WP_Query($args);
            if ($cs1->have_posts()) :
                $cs1_posts = $cs1->posts;
                $post_count = 0;
                foreach ($cs1_posts as $index => $post) :
                    if ($post_count >= 1) {
                        break;
                    }
                    $post_count++;
        ?>
            <div class="md:col-span-12 xl:col-span-8">
                <div class="f_img mb-7">
                    <a href="<?php the_permalink($post->ID); ?>">
                        <?php echo get_the_post_thumbnail($post->ID, 'featured_img', ['class' => 'w-full rounded-md']); ?>
                    </a>
                </div>
                <div class="content">
                    <span class="text-sm leading-[19px] font-normal font-monospace">
                        <?php
                            foreach((get_the_category($post->ID)) as $category){
                                echo $category->name;
                            }
                        ?>
                    </span>
                    <h3 class="text-primaray text-2xl font-Oswald font-semibold mb-[14px] mt-2">
                        <a href="<?php the_permalink($post->ID); ?>"><?php echo get_the_title($post->ID); ?></a>
                    </h3>
                    <p class="text-lg font-normal font-GTamerica text-charcoal">
                        <?php echo wp_trim_words(get_the_excerpt($post->ID), 17, '...'); ?>
                    </p>
                </div>
            </div>

            <?php
            endforeach;
        endif;
        ?>
            <div class="md:col-span-12 xl:col-span-4 flex flex-col gap-5 md:flex-row xl:flex-col xl:gap-y-10">
                <?php
                if ($cs1->have_posts()) :
                    foreach ($cs1_posts as $index => $post) :
                        if ($index >= 1) :
                ?>
                <div class="single_cards">
                    <div class="post_img mb-[14px]">
                        <a href="<?php the_permalink($post->ID); ?>">
                            <?php echo get_the_post_thumbnail($post->ID, 'featured_img', ['class' => 'w-full rounded-md']); ?>
                        </a>
                    </div>
                    <div class="content">
                        <span class="text-sm leading-[19px] font-normal font-monospace">
                            <?php
                                foreach((get_the_category($post->ID)) as $category){
                                    echo $category->name;
                                }
                            ?>
                        </span>
                        <h3 class="text-primaray text-xl font-Oswald font-semibold mt-2">
                            <a href="<?php the_permalink($post->ID); ?>"><?php echo get_the_title($post->ID); ?></a>
                        </h3>
                    </div>
                </div>

                <?php
                            endif;
                        endforeach;
                    endif;
                    wp_reset_postdata();
                    ?>
            </div>
        </div>
    </div>
</section>