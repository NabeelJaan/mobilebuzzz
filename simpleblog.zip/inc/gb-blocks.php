<?php

    add_action('acf/init', 'sb_acf_blocks');
    
    function sb_acf_blocks() {

        // Check function exists.
        if( function_exists('acf_register_block_type') ) {

            // Main Section
            acf_register_block_type([
                "name" => __("Main section"),
                "title" => __("Main Section"),
                "description" => __("Main Section on home page"),
                "render_template" => "inc/blocks/main-sec.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["Main Section", ""],
            ]);

            // Most Recent Post
            acf_register_block_type([
                "name" => __("mrp"),
                "title" => __("Most Recent Post"),
                "description" => __("MRP on home page"),
                "render_template" => "inc/blocks/mrp.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["Most viewed post", ""],
            ]);

            // News Letter
            acf_register_block_type([
                "name" => __("News Letter"),
                "title" => __("News Letter"),
                "description" => __("News Letter on home page"),
                "render_template" => "inc/blocks/news_letter.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["NewsLetter", ""],
            ]);

            // Post by Cat
            acf_register_block_type([
                "name" => __("Post by Cat"),
                "title" => __("Post by Cat"),
                "description" => __("Post by Cat on home page"),
                "render_template" => "inc/blocks/post_by_cat.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["PostByCategory", ""],
            ]);

            // book
            acf_register_block_type([
                "name" => __("book"),
                "title" => __("book"),
                "description" => __("book on home page"),
                "render_template" => "inc/blocks/book.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["book", ""],
            ]);

            // CTA
            acf_register_block_type([
                "name" => __("cta"),
                "title" => __("CTA"),
                "description" => __("CTA on home page"),
                "render_template" => "inc/blocks/cta.php",
                "category" => "simpleblog",
                "icon" => "block-default",
                "keywords" => ["CTA", ""],
            ]);
        }
    }

?>