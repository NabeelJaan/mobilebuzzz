<?php
/**
 * The template for displaying archive pages
 */

get_header();


?>

    <section class="relative px-4 py-[90px] bg-[#d1e8ff] xl:px-0">
        <div class="gen__content max-w-1140px mx-auto">
            <div class="relative hero-content max-w-[750px] mx-auto text-center">

                <h1 class="page-title font-Oswald capitalize text-black text-[45px] leading-[55px] font-bold font-Garnett mb-[10px]s"><?php
                    printf( __( ' %s', ), '<span>' . single_cat_title( '', false ) . '</span>' );
                ?></h1>

            </div>
        </div>
    </section>


	<div class="for_icon max-w-[1140px] mx-auto px-4 py-16 xl:py-24 xl:px-0">


        <div class="grid gap-5 md:grid-cols-2 md:grid-flow-row md:gap-[20px] lg:grid-cols-3 lg:gap-8">

            <?php
                if ( have_posts() ) :

                    while ( have_posts() ) : the_post();

                        get_template_part( 'template-parts/content', 'archive' );

                    endwhile;

                else :

                    get_template_part( 'template-parts/content', 'none' );

                endif;
            ?>
        </div>
        <div>
            
            <?php
                echo '<div class="pagination flex items-center justify-center mt-[24px]">';
                the_posts_pagination(array(
                    'mid_size'  => 2,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ) );
                echo '</div>';
            ?>
        </div>

	</div>

<?php

get_footer();