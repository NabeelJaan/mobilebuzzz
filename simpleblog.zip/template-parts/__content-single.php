<article id="post-<?php the_ID(); ?>" <?php post_class( 'py-16 px-4 xl:px-0' ); ?>>

	<header class="entry-header md:pb-[75px] text-center ">
		<?php the_title( sprintf( '<h1 class="entry-title capitalize max-w-[860px] mx-auto text-2xl lg:text-5xl lg:leading-[55px] font-bold mb-[22px]">', esc_url( get_permalink() ) ), '</h1>' ); ?>

		<div class="flex flex-col items-center justify-center md:flex-row">
			<div class="flex flex-col items-center md:flex-row">
				<?php 
					$author_id = get_the_author_meta('ID');
					$author_name = get_the_author();
					$author_image = get_avatar_url($author_id);
				?>
				<div class="mb-2 md:mb-0 md:mr-2">
					<?php echo '<img class="w-[38px] h-[38px] rounded-full" src="' . $author_image . '" alt="' . $author_name . '">'; ?>
				</div>
				<div>
					<span class="text-charcoal text-sm font-GTamerica font-medium">
						<?php echo 'Written By ' . $author_name; ?>
					</span>
				</div>
			</div>
			<span class="mx-[6px] w-1 h-1 rounded-full bg-[#ded5d1]"></span>
			<time datetime="<?php echo get_the_date( 'c' ); ?>" itemprop="datePublished" class="text-sm text-charcoal font-GTamerica font-normal"><?php echo get_the_date(); ?></time>
		</div>
		<div class="mt-11 mb-4">
			<?php the_post_thumbnail( 'single_f_img', ['class' => 'w-full rounded-lg'] ); ?>
		</div>
	</header>

	<div class="entry-content max-w-[728px] mx-auto">

		<?php the_content(); ?>

		<?php
			wp_link_pages(
				array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tailpress' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tailpress' ) . ' </span>%',
					'separator'   => '<span class="screen-reader-text">, </span>',
				)
			);
		?>

		<div class="author__box md:text-left md:flex md:gap-5 md:justify-between border-t pt-[30px]">
			<?php 
				$author_id = get_the_author_meta('ID');
				$author_name = get_the_author();
				$author_image = get_avatar_url($author_id);
				$author_bio = get_the_author_meta('description', $author_id);
			?>
			<div class="md:w-[12%]">
				<?php echo '<img class="w-[78px] h-[78px] rounded-full mb-4 md:mb-0" src="' . $author_image . '" alt="' . $author_name . '">'; ?>
			</div>
			<div class="md:w-[88%]">
				<h5 class="mb-3 text-xl leading-6 font-semibold font-Garnett text-charcoal">
					<a href="#" class="text-xl font-semibold"><?php echo $author_name; ?></a>
				</h5>
				<p class="font-normal font-GTamerica text-base text-light leading-6">
					<?php echo $author_bio; ?>
				</p>
			</div>
		</div>

	</div>

</article>
